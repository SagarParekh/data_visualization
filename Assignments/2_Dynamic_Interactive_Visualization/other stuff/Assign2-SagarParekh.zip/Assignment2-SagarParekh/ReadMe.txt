How to Run:
	You will need to start a localhost session inorder to run the file.

	Place the tennis folder inside:
		Tomcat -> webapps -> ROOT 

	Open the browser and type : http://localhost:8080/tennis/AustralianOpenInteractiveViz.html
	(8080 here is the port assigned to localhost)