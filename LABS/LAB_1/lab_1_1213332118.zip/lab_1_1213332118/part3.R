A<-c(2,3,5,7,11)
B<-seq(100,108, by=2)
B

c(A,B)

A+B

airports<-c("JFK","LGA","EWR","SFO")
length(airports)

airports[4] #How about airports[-4] ?

airports[1:3]

airports[c(2,4)]