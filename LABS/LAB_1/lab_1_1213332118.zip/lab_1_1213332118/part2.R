1+2

3^2

#Try built-in functions
exp(2)-log(100)

# Define a compound function
sqrt(abs(-2))

a<-1
b=2
(a+b)^2

#Define a function z=f(x,y)
f<-function(x, y) z<-(y^2-x^2)*pi
print(f(1,2))

#See what variables you have
ls()

#Remove a and b from working space
rm(a,b) # Remove all with "rm(list=ls())"
ls()